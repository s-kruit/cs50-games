--[[
    GD50
    Super Mario Bros. Remake

    -- GameLevel Class --

    Author: Colton Ogden
    cogden@cs50.harvard.edu
]]

GameLevel = Class{}

function GameLevel:init(entities, objects, tilemap)
    self.entities = entities
    self.objects = objects
    self.tileMap = tilemap
end

--[[
    Remove all nil references from tables in case they've set themselves to nil.
]]
function GameLevel:clear()
    for i = #self.objects, 1, -1 do
        if not self.objects[i] then
            table.remove(self.objects, i)
        end
    end

    for i = #self.entities, 1, -1 do
        if not self.objects[i] then
            table.remove(self.objects, i)
        end
    end
end

function GameLevel:update(dt)
    self.tileMap:update(dt)

    for k, object in pairs(self.objects) do
        object:update(dt)
    end

    for k, entity in pairs(self.entities) do
        entity:update(dt)
    end
end

function GameLevel:render()
    self.tileMap:render()

    for k, object in pairs(self.objects) do
        object:render()
    end

    for k, entity in pairs(self.entities) do
        entity:render()
    end
end

--[[
    Spawn a goalpost at the end of the level, consisting of one flag object
    and 3 flagpole objects.
]]
function GameLevel:spawnFlag()
    
    local noChasm = false
    local x = #self.tileMap.tiles[1]
    
    -- iterate through tile columns from end until we reach first non-chasm
    while noChasm == false do
        if self:isChasm(x) then
            x = x - 1
        else
            noChasm = true
        end
    end
    
    -- TODO: spawn flag and flagpole objects in x column. The onCollide(player, obj) function for each will
    -- need to set player.flagReached = true
    
    
end

--[[
    Return whether or not a column of tiles corresponding to a given x position includes a chasm 
    (i.e. all tiles in column are non-collidable).
]]
function GameLevel:isChasm(x)
    
    -- iterate through each tile in a column of tiles
    for y = 1, #self.tileMap do
    
        -- if tile is collidable, return false
        if self.tileMap.tiles[y][x]:collidable() then
            return false
        end
    end
    
    -- return true if no tiles were collidable
    return true
end

